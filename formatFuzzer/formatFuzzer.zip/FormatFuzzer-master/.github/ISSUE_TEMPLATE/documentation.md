---
name: Documentation Improvement
about: Suggest changes to documentation
title: 'Documentation Improvement'
labels: 'documentation'
assignees: 'd0c-s4vage'
---

## Describe what you would like to see changed in the documentation

Section X in the documentation is unclear

or

A new section "X" in the documentation would be very helpful

or

other

## Additional context

Add any other context or screenshots about the feature request here.
