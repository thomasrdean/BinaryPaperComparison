identify -verbose - <out.bmp 2>/dev/null | grep -q Elapsed
