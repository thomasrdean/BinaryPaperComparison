identify -verbose - <out.gif 2>/dev/null | grep -q Elapsed
#identify -verbose - <out.gif >/dev/null 2>/dev/null
#gif2png out.gif >/dev/null 2>/dev/null
