identify -verbose - <out.png 2>/dev/null | grep -q Elapsed
#identify -verbose - <out.png >/dev/null 2>/dev/null
#readpng <out.png 2>/dev/null
#pngimage out.png >/dev/null 2>/dev/null
