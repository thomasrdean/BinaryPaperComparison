tcpdump -nr - <out.pcap >/dev/null 2>/dev/null
