ffmpeg -y -f avi -i - output.avi <out.avi 2>/dev/null
