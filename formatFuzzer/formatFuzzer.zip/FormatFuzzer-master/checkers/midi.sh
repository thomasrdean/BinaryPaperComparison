! timidity - -Ol -o /dev/null <out.midi 2>/dev/null | grep -q ^-:
