wavpack -y - -o output.wav <out.wav 2>/dev/null
#ffmpeg -y -i - output.wav <out.wav 2>/dev/null
