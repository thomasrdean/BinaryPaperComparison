ffmpeg -y -i - -c:v mpeg4 -c:a copy output.mp4 <out.mp4 2>/dev/null
