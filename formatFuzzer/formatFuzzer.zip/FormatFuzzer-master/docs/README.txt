To create a blog post, go to /docs/_posts in the FormatFuzzer git repo and add a new .md file (like the existing one). If you have jekyll installed, you can run 

   $ bundle exec jekyll serve

and open

    http://localhost:4000/FormatFuzzer/

to obtain a preview before committing/pushing.
