#!/bin/sh
./generateParser.sh -i ConformSCL5 -o ConformSrc
